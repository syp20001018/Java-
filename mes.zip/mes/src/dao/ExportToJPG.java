package dao;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.imageio.ImageIO;

import com.itextpdf.text.DocumentException;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;
import jxl.read.biff.BiffException;
import vo.Logistics;

public class ExportToJPG {
	int width=700;//JPG的宽度
	int height=300;//JPG的长度

    // 生成JPG
    public void createJpg(String path,BufferedImage image) {
        try{
            FileOutputStream fos = new FileOutputStream(path);
            BufferedOutputStream bos = new BufferedOutputStream(fos);
            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(bos);
            encoder.encode(image);
            bos.close();
            fos.close();

        }catch(FileNotFoundException fnfe){
            System.out.println(fnfe);
        }catch(IOException ioe){
            System.out.println(ioe);
        }
    }
    
    public void graphicsGeneration(Logistics log) throws FileNotFoundException, IOException
    {
    	BufferedImage image1 = ImageIO.read(new FileInputStream("PNG图片.png"));
    	int imageWidth = 1000;// ͼƬ�Ŀ��  
        int imageHeight = 1000;// ͼƬ�ĸ߶�  
        BufferedImage image = new BufferedImage(imageWidth, imageHeight,  BufferedImage.TYPE_INT_RGB); 
        Graphics g = image.getGraphics();  
        g.setColor(Color.white);  
        g.fillRect(0, 0, imageWidth, imageHeight); //��䱳����ɫ 
        g.setColor(Color.black);
        //������Ϊ800����Ϊ400�ľ��ο�
        g.drawRect(100,100,800,400); 
        g.drawLine(100,200,900,200);
        g.drawLine(100,300,900,300);
        g.drawLine(100,400,900,400);
        g.drawLine(500,300,500,400);
        g.setFont(new Font("", Font.BOLD, 60));   
        g.drawString("EMS快递公司", 180, 95);//����EMS��������
        g.setFont(new Font("", Font.BOLD, 25));  
        g.drawString("", 480, 95);
        g.drawString(log.getTaskNO(), 580, 95);
        g.drawString("", 120, 130);//�ļ�������
        g.drawString(log.getSender(), 220, 130);
        g.drawString("", 380, 130);
        g.drawString("电话："+log.getSenPhone(), 520, 130);
        g.drawString("", 120, 160);
        g.drawString(log.getSenAdd(), 180, 160);
        g.drawString("", 120, 190);
        g.drawString(log.getSenPost(), 200, 190);
        g.drawString("", 120, 230);
        g.drawString(log.getRecipent(),220, 230);
        g.drawString("", 380, 230);
        g.drawString("电话："+log.getRecPhone(),520, 230);
        g.drawString("", 120, 260);
        g.drawString(log.getRecAdd(), 180, 260);
        g.drawString("", 120, 290);
        g.drawString(log.getRecPoSt(), 200, 290);
        g.drawString("", 410, 340);
        g.drawString("", 410, 380);
        g.setFont(new Font("", Font.BOLD, 18)); 
        g.drawString("", 520, 330);
        g.drawString("", 520, 380);
        g.drawString("", 120, 330);
        g.drawString(log.getRemarks(), 220, 330);
        g.drawString("", 120, 380);
        g.drawString(log.getAmount(), 220, 380);
        g.drawString("", 120, 420);
        g.drawString(log.getTaskNO(), 450, 488);
        g.drawImage(image1, 410, 420, 250,50, null);
        createJpg("JPG图片.jpg", image);


    }
	public static void main(String[] args) throws BiffException, IOException, DocumentException {
		// TODO Auto-generated method stub
		String imgPath = "PNG图片.png";     
		File file=new File("物流信息.xls");
		String imagePath = "JPG图片.jpg";			
		String pdfPath = "PDF文件.pdf";
		Logistics logistics=new ReadExcel().readFromExcel(file);           
        new CreatBarCode().encode(imgPath);
		new ExportToJPG().graphicsGeneration(logistics);
		new ExportToPDF().jpgToPdf(imagePath, pdfPath);
		System.out.println("PNG、JPG、PDF都已生成！");
	}

}
